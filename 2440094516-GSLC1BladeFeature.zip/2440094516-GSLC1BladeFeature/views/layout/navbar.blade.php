<nav class="navbar navbar-dark bg-dark sticky-top">
    <div class="container-fluid d-flex justify-content-start">
        <a class="navbar-brand" href="/">
            <img src="https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/global/dota2_logo_horiz.png" alt="Dota 2"
            width="230px" height="50px">
        </a>
        <a class="nav-link text-bg-dark" aria-current="page" href="/">HEROES</a>
    </div>
  </nav>
