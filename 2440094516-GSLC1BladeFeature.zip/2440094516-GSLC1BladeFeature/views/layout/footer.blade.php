<footer class="bg-dark justify-content-center">
    <h1 class="p-3">&copy; Copyright 2022 || 2440094516 - Felice Cendekia ||</h1>
</footer>
